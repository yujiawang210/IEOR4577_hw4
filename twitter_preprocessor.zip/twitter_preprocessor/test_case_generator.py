"""
Tweets Preprocessor Test Case Generator
"""

class TestCasesGenerator:
    """define test case generator class"""

    clean = [
        {
            'case':'RT @BBMAs: Who is most excited to see at the #BBMAs? Everybody. And honestly same. https://t.co/76BFUvHIlD',
            'expected':'who is most excited to see at the  everybody and honestly same'
        }
    ]


    tokenize = [
        {
            'case': 'who is  most excited to see at the  everybody and honestly same',
            'expected': ['who', 'is', 'most', 'excited', 'to', 'see', 'at', 'the', 'everybody', 'and', 'honestly', 'same']
        }
    ]

    index = [
        {
            'case': ['who', 'is', 'most', 'excited', 'to', 'see', 'at', 'the', 'everybody', 'and', 'honestly', 'same'],
            'expected': [129, 34, 451, 872, 18, 165, 68, 15, 899, 28, 1649, 452]
        }
    ]

    padding = [
        {
            'case': [129, 34, 451, 872, 18, 165, 68, 15, 899, 28, 1649, 452],
            'expected': [129, 34, 451, 872, 18, 165, 68, 15, 899, 28, 1649, 452, 0, 0, 0, 0, 0, 0, 0, 0]
        }
        ]

    preprocessing = [
        {
            'case': 'RT @BBMAs: Who is most excited to see at the #BBMAs? Everybody. And honestly same. https://t.co/76BFUvHIlD',
            'expected': [129, 34, 451, 872, 18, 165, 68, 15, 899, 28, 1649, 452, 0, 0, 0, 0, 0, 0, 0, 0]
        }
    ]
