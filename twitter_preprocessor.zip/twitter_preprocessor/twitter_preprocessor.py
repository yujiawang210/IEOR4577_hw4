"""
Tweets Preprocessor
"""
import os
import zipfile
from nltk import re
from nltk.tokenize import TweetTokenizer

# load GloVe embedding dictionary
MAX_LENGTH = 50000
EMB_DIC = {}

MODULE_PATH = os.path.abspath(__file__)
PATH = os.path.join(os.path.dirname(MODULE_PATH), "resources", "glove.twitter.27B.25d.txt")

if ".zip/" in PATH:
    ARCHIVE_PATH = os.path.abspath(PATH)
    SPLIT = ARCHIVE_PATH.split(".zip/")
    ARCHIVE_PATH = SPLIT[0] + ".zip"
    INSIDE_PATH = SPLIT[1]
    ARCHIVE = zipfile.ZipFile(ARCHIVE_PATH, "r")
    EMBEDDINGS = ARCHIVE.read(INSIDE_PATH).decode("utf8").split("\n")
else:
    EMBEDDINGS = open(PATH, "r", encoding="utf8").read().split("\n")

for index, row in enumerate(EMBEDDINGS):
    split = row.split(" ")
    if index >= MAX_LENGTH:
        pass
    EMB_DIC[split[0]] = index

EMB_DIC.pop('<unknown>', None)
EMB_DIC.pop('<unk>', None)


class TwitterPreprocessor:
    """define twitter preprocessor Class"""

    # - dunder function -
    def __init__(self, max_length_tweet=20, max_length_dictionary=5000):

        self.max_length_tweet = max_length_tweet
        self.max_length_dictionary = max_length_dictionary

        self.regex_url = re.compile(r'https?:\/\/[A-Za-z0-9\/\.\-\#]*')
        self.regex_hashtag = re.compile(r'#\w*')
        self.regex_mention = re.compile(r'@\w*')
        self.regex_twitter_handle = re.compile(r'RT')
        self.regex_punctutation = re.compile(r'[^\w\s]')

        self.tokenizer = TweetTokenizer()

    # - twitter preprocessor main methods -
    def clean_text(self, input_text):
        """cleaning the raw text"""
        cleaned_text = re.sub(pattern=self.regex_url, repl='', string=input_text)
        cleaned_text = re.sub(pattern=self.regex_hashtag, repl='', string=cleaned_text)
        cleaned_text = re.sub(pattern=self.regex_mention, repl='', string=cleaned_text)
        cleaned_text = re.sub(pattern=self.regex_twitter_handle, repl='', string=cleaned_text)
        cleaned_text = re.sub(pattern=self.regex_punctutation, repl='', string=cleaned_text)
        cleaned_text = cleaned_text.lower().strip()
        return cleaned_text

    def tokenize_text(self, input_text):
        """converting a string into an array of tokens"""
        tokens = self.tokenizer.tokenize(input_text)
        return tokens

    def replace_token_with_index(self, input_list):
        """replacing tokens with index"""
        emb_index = dict(list(EMB_DIC.items())[:self.max_length_dictionary])
        output_list = []
        for token in input_list:
            output_list.append(emb_index[token])
        return output_list

    def pad_sequence(self, input_sequence):
        """padding a list of indices with 0 until maximum length"""
        if len(input_sequence) < self.max_length_tweet:
            input_sequence.extend([0] * (self.max_length_tweet - len(input_sequence)))
        else:
            input_sequence = input_sequence[0:self.max_length_tweet]
        return input_sequence

    def preprocessing(self, text):
        """run end to end preprocessing"""
        cleaned_text = self.clean_text(text)
        tokens = self.tokenize_text(cleaned_text)
        embedding_indexes = self.replace_token_with_index(tokens)
        padded_indexes = self.pad_sequence(embedding_indexes)
        return padded_indexes

