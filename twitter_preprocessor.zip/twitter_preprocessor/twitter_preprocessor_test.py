"""
Testing Tweets Preprocessor
"""
import unittest
from twitter_preprocessor import TwitterPreprocessor
from test_case_generator import TestCasesGenerator

class Tests(unittest.TestCase):
    """define testing class"""

    def setUp(self):
        return

    def test_clean_text(self):
        """testing cleaning"""
        for test_case in getattr(TestCasesGenerator, 'clean'):
            input = test_case['case']
            result = TwitterPreprocessor().clean_text(input)
            expected_result = test_case['expected']
            self.assertEqual(result, expected_result)

    def test_tokenize_text(self):
        """testing tokenizing"""
        for test_case in getattr(TestCasesGenerator, 'tokenize'):
            input = test_case['case']
            result = TwitterPreprocessor().tokenize_text(input)
            expected_result = test_case['expected']
            self.assertEqual(result, expected_result)

    def test_replace_token_with_index(self):
        """testing indexing"""
        for test_case in getattr(TestCasesGenerator, 'index'):
            input = test_case['case']
            result = TwitterPreprocessor().replace_token_with_index(input)
            expected_result = test_case['expected']
            self.assertEqual(result, expected_result)

    def test_pad_sequence(self):
        """testing pad sequence"""
        for test_case in getattr(TestCasesGenerator, 'padding'):
            input = test_case['case']
            result = TwitterPreprocessor().pad_sequence(input)
            expected_result = test_case['expected']
            self.assertEqual(result, expected_result)

    def test_preprocessing(self):
        """testing end to end preprocessing"""
        for test_case in getattr(TestCasesGenerator, 'preprocessing'):
            input = test_case['case']
            result = TwitterPreprocessor().preprocessing(input)
            expected_result = test_case['expected']
            self.assertEqual(result, expected_result)

